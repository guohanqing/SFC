#ifndef __KEY_H_INCLUDE__
#define __KEY_H_INCLUDE__

#include <rtthread.h>

void key_to_touch( rt_uint16_t x , rt_uint16_t y );

#endif

